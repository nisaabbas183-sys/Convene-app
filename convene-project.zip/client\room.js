import { Device } from 'mediasoup-client';

const $ = (id) => document.getElementById(id);
const roomId = location.pathname.split('/').pop();

const gridEl = $('grid');
const peopleEl = $('people');
const countEl = $('count');
const errorEl = $('error');
const toastEl = $('toast');
const lockedPill = $('lockedPill');
const sideEl = $('side');
const chatLog = $('chatLog');
const chatInput = $('chatInput');

$('roomCode').textContent = roomId;
const socket = io({ transports: ['websocket'] });// global from /socket.io/socket.io.js

// Promise wrapper: socket.emit with an acknowledgement. Rejects when the server sends { error }.
const request = (event, data = {}) =>
  new Promise((resolve, reject) => {
    socket.emit(event, data, (res) => {
      if (res && res.error) reject(new Error(res.error));
      else resolve(res || {});
    });
  });

/* ---------- State ---------- */
let selfId = null;
let myId = null;
let myName = '';
let roomState = null;
let finished = false;
let ready = false;

let device = null;
let sendTransport = null;
let recvTransport = null;

let micProducer = null;
let camProducer = null;
let screenProducer = null;
let micTrack = null;
let camTrack = null;
let screenTrack = null;

const tiles = new Map(); // tile key -> element. Key is a socket id, or "screen:<socket id>"
const consumers = new Map(); // producerId -> { consumer, peerId, source, kind }
const inflight = new Set();
const closedEarly = new Set();
const pendingProducers = [];

let activeTab = 'people';
let unread = 0;

const AUDIO_CONSTRAINTS = { echoCancellation: true, noiseSuppression: true };
const VIDEO_CONSTRAINTS = { width: { ideal: 640 }, height: { ideal: 360 }, frameRate: { ideal: 24 } };
const MIC_OFF_SVG =
  '<svg class="mic-off" viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M3 3l18 18"/></svg>';

/* ---------- UI helpers ---------- */
function initials(name) {
  return (name || '').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('') || '?';
}

let toastTimer;
function toast(message) {
  toastEl.textContent = message;
  toastEl.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2400);
}

function showError(message) {
  errorEl.textContent = message;
  errorEl.hidden = false;
}

function showOverlay(title, text) {
  $('ovTitle').textContent = title;
  $('ovText').textContent = text;
  $('overlay').hidden = false;
}

function nameOf(peerId) {
  const p = roomState && roomState.participants.find((x) => x.id === peerId);
  return p ? p.name : 'Participant';
}

let audioWaiting = false;
function needAudioUnlock() {
  if (audioWaiting) return;
  audioWaiting = true;
  toast('Click anywhere on the page to enable meeting audio.');
  document.addEventListener(
    'click',
    () => {
      document.querySelectorAll('audio').forEach((a) => a.play().catch(() => {}));
      audioWaiting = false;
    },
    { once: true }
  );
}

/* ---------- Tiles ---------- */
function ensureTile(key, name, opts = {}) {
  let tile = tiles.get(key);
  if (tile) return tile;

  tile = document.createElement('div');
  tile.className = 'tile' + (opts.screen ? ' screen' : '') + (opts.self ? ' self' : '');
  tile.dataset.key = key;

  const video = document.createElement('video');
  video.autoplay = true;
  video.playsInline = true;
  video.muted = true; // remote sound plays through a separate <audio> element

  const circle = document.createElement('div');
  circle.className = 'initials';
  circle.textContent = initials(name);

  const label = document.createElement('div');
  label.className = 'label';
  label.innerHTML = MIC_OFF_SVG; // static markup only
  const nameEl = document.createElement('span');
  nameEl.className = 'name';
  nameEl.textContent = name;
  label.appendChild(nameEl);

  tile.append(video, circle, label);
  if (opts.self || opts.screen) gridEl.prepend(tile);
  else gridEl.appendChild(tile);
  tiles.set(key, tile);
  return tile;
}

function removeTile(key) {
  const tile = tiles.get(key);
  if (tile) tile.remove();
  tiles.delete(key);
}

function setTileVideo(tile, track) {
  const video = tile.querySelector('video');
  video.srcObject = track ? new MediaStream([track]) : null;
  tile.classList.toggle('has-video', !!track);
}

/* ---------- Rendering room state ---------- */
function miniButton(text, onClick, danger) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'mini' + (danger ? ' danger' : '');
  b.textContent = text;
  b.onclick = onClick;
  return b;
}

function renderState(state) {
  if (!state) return;
  const prev = roomState;
  roomState = state;
  const iAmHost = state.hostId === selfId;
  if (prev && prev.hostId !== selfId && iAmHost) toast('You are now the host.');

  const n = state.participants.length;
  countEl.textContent = `${n} participant${n === 1 ? '' : 's'}`;
  lockedPill.hidden = !state.locked;
  document.querySelectorAll('.host-only').forEach((el) => (el.hidden = !iAmHost));
  $('lockLabel').textContent = state.locked ? 'Unlock room' : 'Lock room';
  $('lock').dataset.label = state.locked ? 'Unlock room' : 'Lock room';
  $('lock').setAttribute('aria-label', state.locked ? 'Unlock room' : 'Lock room');

  peopleEl.innerHTML = '';
  const present = new Set();

  state.participants.forEach((p) => {
    present.add(p.id);
    const isSelf = p.id === selfId;

    const tile = ensureTile(p.id, p.name, { self: isSelf });
    tile.querySelector('.name').textContent = p.name + (isSelf ? ' (You)' : '');
    tile.classList.toggle('muted', !p.mic);

    const li = document.createElement('li');
    const avatar = document.createElement('div');
    avatar.className = 'avatar';
    avatar.textContent = initials(p.name);
    const label = document.createElement('span');
    label.textContent = p.name + (isSelf ? ' (You)' : '');
    li.append(avatar, label);

    if (p.isHost) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = 'Host';
      li.appendChild(b);
    }

    if (iAmHost && !isSelf) {
      const actions = document.createElement('div');
      actions.className = 'row-actions';
      if (p.mic) {
        actions.appendChild(
          miniButton('Mute', () => request('host-mute', { targetId: p.id }).catch((e) => toast(e.message)))
        );
      }
      actions.appendChild(
        miniButton(
          'Remove',
          () => {
            if (confirm(`Remove ${p.name} from the meeting?`)) {
              request('host-remove', { targetId: p.id }).catch((e) => toast(e.message));
            }
          },
          true
        )
      );
      li.appendChild(actions);
    }
    peopleEl.appendChild(li);
  });

  // Remove tiles of people who are no longer in the room
  [...tiles.keys()].forEach((key) => {
    const pid = key.startsWith('screen:') ? key.slice(7) : key;
    if (!present.has(pid)) removeTile(key);
  });
}

/* ---------- Remote media ---------- */
function attachConsumer({ consumer, peerId, source, kind }) {
  if (source === 'screen') {
    const tile = ensureTile('screen:' + peerId, `${nameOf(peerId)}'s screen`, { screen: true });
    setTileVideo(tile, consumer.track);
    return;
  }
  const tile = ensureTile(peerId, nameOf(peerId));
  if (kind === 'video') {
    setTileVideo(tile, consumer.track);
  } else {
    let audio = tile.querySelector('audio');
    if (!audio) {
      audio = document.createElement('audio');
      audio.autoplay = true;
      tile.appendChild(audio);
    }
    audio.srcObject = new MediaStream([consumer.track]);
    audio.play().catch(needAudioUnlock);
  }
}

async function consumeProducer({ producerId }) {
  if (consumers.has(producerId) || inflight.has(producerId)) return;
  inflight.add(producerId);
  try {
    const data = await request('consume', { producerId, rtpCapabilities: device.rtpCapabilities });
    const consumer = await recvTransport.consume({
      id: data.id,
      producerId: data.producerId,
      kind: data.kind,
      rtpParameters: data.rtpParameters,
    });
    if (closedEarly.has(producerId)) {
      closedEarly.delete(producerId);
      consumer.close();
      return;
    }
    const entry = { consumer, peerId: data.peerId, source: data.source, kind: data.kind };
    consumers.set(producerId, entry);
    attachConsumer(entry);
    await request('resume-consumer', { consumerId: consumer.id });
  } catch (err) {
    console.error('Could not receive stream:', err);
  } finally {
    inflight.delete(producerId);
  }
}

function closeConsumer(producerId) {
  const entry = consumers.get(producerId);
  if (!entry) {
    if (inflight.has(producerId)) closedEarly.add(producerId);
    return;
  }
  entry.consumer.close();
  consumers.delete(producerId);

  if (entry.source === 'screen') {
    removeTile('screen:' + entry.peerId);
    return;
  }
  const tile = tiles.get(entry.peerId);
  if (!tile) return;
  if (entry.kind === 'video') {
    setTileVideo(tile, null);
  } else {
    const audio = tile.querySelector('audio');
    if (audio) {
      audio.srcObject = null;
      audio.remove();
    }
  }
}

function dropPeerConsumers(peerId) {
  [...consumers.entries()].forEach(([producerId, entry]) => {
    if (entry.peerId === peerId) closeConsumer(producerId);
  });
}

/* ---------- Local media ---------- */
function setBtn(btn, label, off, active) {
  btn.querySelector('span').textContent = label;
  btn.dataset.label = label; // used by the hover tooltip
  btn.setAttribute('aria-label', label);
  btn.classList.toggle('off', !!off);
  btn.classList.toggle('active', !!active);
}

function updateButtons() {
  const micOn = !!micProducer && !micProducer.paused;
  setBtn($('mic'), micOn ? 'Mute' : 'Unmute', !micOn, false);
  setBtn($('cam'), camProducer ? 'Stop video' : 'Start video', !camProducer, false);
  setBtn($('share'), screenProducer ? 'Stop sharing' : 'Share screen', false, !!screenProducer);
}

async function publishMic(track) {
  micTrack = track;
  micProducer = await sendTransport.produce({ track, appData: { source: 'mic' } });
}

async function publishCam(track) {
  camTrack = track;
  camProducer = await sendTransport.produce({
    track,
    encodings: [{ maxBitrate: 500000 }],
    appData: { source: 'cam' },
  });
  const tile = tiles.get(selfId);
  if (tile) setTileVideo(tile, track);
}

async function startMic() {
  if (micProducer) return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: AUDIO_CONSTRAINTS });
    await publishMic(stream.getAudioTracks()[0]);
  } catch (e) {
    toast('Microphone is not available. Check your browser permissions.');
  }
  updateButtons();
}

async function startCam() {
  if (camProducer) return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: VIDEO_CONSTRAINTS });
    await publishCam(stream.getVideoTracks()[0]);
  } catch (e) {
    toast('Camera is not available. Check your browser permissions.');
  }
  updateButtons();
}

async function stopCam() {
  if (!camProducer) return;
  const id = camProducer.id;
  camProducer.close();
  camProducer = null;
  if (camTrack) camTrack.stop();
  camTrack = null;
  const tile = tiles.get(selfId);
  if (tile) setTileVideo(tile, null);
  await request('close-producer', { producerId: id }).catch(() => {});
  updateButtons();
}

async function startInitialMedia() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    showError('Camera and microphone need a secure connection (HTTPS or localhost). You can still watch and chat.');
    updateButtons();
    return;
  }
  let stream = null;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: AUDIO_CONSTRAINTS, video: VIDEO_CONSTRAINTS });
  } catch (e) {
    stream = null; // fall back to asking for each device separately
  }
  if (stream) {
    try {
      await publishMic(stream.getAudioTracks()[0]);
      await publishCam(stream.getVideoTracks()[0]);
    } catch (e) {
      console.error(e);
      toast('Could not start your camera or microphone.');
    }
    updateButtons();
  } else {
    await startMic();
    await startCam();
  }
}

async function toggleMic() {
  if (!micProducer) return startMic();
  if (micProducer.paused) {
    micProducer.resume();
    await request('resume-producer', { producerId: micProducer.id }).catch(() => {});
  } else {
    micProducer.pause();
    await request('pause-producer', { producerId: micProducer.id }).catch(() => {});
  }
  updateButtons();
}

async function toggleCam() {
  if (camProducer) await stopCam();
  else await startCam();
}

async function stopShare() {
  if (!screenProducer) return;
  const id = screenProducer.id;
  screenProducer.close();
  screenProducer = null;
  if (screenTrack) {
    screenTrack.onended = null;
    screenTrack.stop();
    screenTrack = null;
  }
  removeTile('screen:' + selfId);
  await request('close-producer', { producerId: id }).catch(() => {});
  updateButtons();
}

async function toggleShare() {
  if (screenProducer) return stopShare();
  if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
    return toast('Screen sharing is not supported on this device.');
  }
  try {
    const stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: { ideal: 15 } }, audio: false });
    screenTrack = stream.getVideoTracks()[0];
    screenProducer = await sendTransport.produce({
      track: screenTrack,
      encodings: [{ maxBitrate: 1500000 }],
      appData: { source: 'screen' },
    });
    screenTrack.onended = stopShare; // user clicked the browser's "Stop sharing" button
    const tile = ensureTile('screen:' + selfId, 'Your screen', { screen: true, self: true });
    setTileVideo(tile, screenTrack);
  } catch (e) {
    if (e.name !== 'NotAllowedError') toast('Could not start screen sharing.');
  }
  updateButtons();
}

/* ---------- Chat ---------- */
function updateUnread() {
  [$('unreadTab'), $('unreadBtn')].forEach((el) => {
    el.textContent = String(unread);
    el.hidden = unread === 0;
  });
}

function setTab(tab) {
  activeTab = tab;
  document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === tab));
  $('panelPeople').hidden = tab !== 'people';
  $('panelChat').hidden = tab !== 'chat';
  if (tab === 'chat') {
    unread = 0;
    updateUnread();
    chatLog.scrollTop = chatLog.scrollHeight;
  }
}

function addChat(m, silent) {
  const mine = m.userId === myId;
  const item = document.createElement('div');
  item.className = 'msg' + (mine ? ' mine' : '');
  const meta = document.createElement('div');
  meta.className = 'meta';
  const time = new Date(m.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  meta.textContent = `${mine ? 'You' : m.name} · ${time}`;
  const body = document.createElement('div');
  body.className = 'body';
  body.textContent = m.text;
  item.append(meta, body);
  chatLog.appendChild(item);
  chatLog.scrollTop = chatLog.scrollHeight;

  const chatVisible = activeTab === 'chat' && sideEl.offsetParent !== null;
  if (!silent && !mine && !chatVisible) {
    unread += 1;
    updateUnread();
  }
}

$('chatForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;
  chatInput.value = '';
  request('chat-message', { text }).catch((err) => toast(err.message));
});

document.querySelectorAll('.tab').forEach((t) => (t.onclick = () => setTab(t.dataset.tab)));

$('chatBtn').onclick = () => {
  const mobile = window.matchMedia('(max-width: 720px)').matches;
  if (mobile && sideEl.classList.contains('open')) {
    sideEl.classList.remove('open');
    return;
  }
  setTab('chat');
  sideEl.classList.add('open');
  if (!mobile) chatInput.focus();
};

/* ---------- Buttons ---------- */
$('mic').onclick = toggleMic;
$('cam').onclick = toggleCam;
$('share').onclick = toggleShare;

$('copy').onclick = async () => {
  try {
    await navigator.clipboard.writeText(location.href);
    toast('Meeting link copied');
  } catch (e) {
    toast('Copy failed. Copy the link from the address bar.');
  }
};

$('lock').onclick = () => {
  request('host-lock', { locked: !(roomState && roomState.locked) }).catch((e) => toast(e.message));
};
$('muteAll').onclick = () => {
  request('host-mute-all')
    .then(() => toast('Everyone else has been muted.'))
    .catch((e) => toast(e.message));
};
$('endAll').onclick = () => {
  if (confirm('End the meeting for everyone?')) request('host-end').catch((e) => toast(e.message));
};

function teardown() {
  [micTrack, camTrack, screenTrack].forEach((t) => {
    try { if (t) t.stop(); } catch (e) { /* ignore */ }
  });
  try { if (sendTransport) sendTransport.close(); } catch (e) { /* ignore */ }
  try { if (recvTransport) recvTransport.close(); } catch (e) { /* ignore */ }
}

$('leave').onclick = () => {
  finished = true;
  socket.emit('leave-room');
  teardown();
  location.href = '/app';
};

/* ---------- Socket events ---------- */
socket.on('connect_error', (err) => {
  if (err.message === 'unauthorized') {
    location.href = '/login?next=' + encodeURIComponent(location.pathname);
  } else {
    showError('Connection problem. Please check your internet and reload.');
  }
});

// Page is being closed or navigated away: this is not a connection problem
window.addEventListener('beforeunload', () => { finished = true; });
window.addEventListener('pagehide', () => { finished = true; });

socket.on('disconnect', (reason) => {
  console.log('Socket disconnected:', reason);
  if (finished) return;
  finished = true;
  teardown();
  showOverlay('Connection lost', 'You were disconnected from the meeting. Reload the page to rejoin.');
});

socket.on('participant-joined', ({ name, state }) => {
  renderState(state);
  toast(`${name} joined`);
});

socket.on('participant-left', ({ id, name, state }) => {
  dropPeerConsumers(id);
  renderState(state);
  toast(`${name} left`);
});

socket.on('room-state', ({ state }) => renderState(state));

socket.on('new-producer', (p) => {
  if (!ready) pendingProducers.push(p);
  else consumeProducer(p);
});

socket.on('producer-closed', ({ producerId }) => closeConsumer(producerId));

socket.on('chat-message', (m) => addChat(m, false));

socket.on('force-muted', () => {
  if (micProducer && !micProducer.paused) micProducer.pause();
  updateButtons();
  toast('The host muted you.');
});

socket.on('removed', () => {
  finished = true;
  teardown();
  showOverlay('Removed from meeting', 'The host removed you from this meeting.');
});

socket.on('meeting-ended', () => {
  finished = true;
  teardown();
  showOverlay('Meeting ended', 'The host ended this meeting for everyone.');
});

/* ---------- Join flow ---------- */
async function createTransports() {
  const s = await request('create-transport', { direction: 'send' });
  sendTransport = device.createSendTransport(s);
  sendTransport.on('connect', ({ dtlsParameters }, callback, errback) => {
    request('connect-transport', { transportId: sendTransport.id, dtlsParameters })
      .then(() => callback())
      .catch(errback);
  });
  sendTransport.on('produce', ({ kind, rtpParameters, appData }, callback, errback) => {
    request('produce', { transportId: sendTransport.id, kind, rtpParameters, appData })
      .then(({ id }) => callback({ id }))
      .catch(errback);
  });
  sendTransport.on('connectionstatechange', (state) => {
    if (state === 'failed') showError('Your connection to the meeting failed. Reload the page to try again.');
  });

  const r = await request('create-transport', { direction: 'recv' });
  recvTransport = device.createRecvTransport(r);
  recvTransport.on('connect', ({ dtlsParameters }, callback, errback) => {
    request('connect-transport', { transportId: recvTransport.id, dtlsParameters })
      .then(() => callback())
      .catch(errback);
  });
}

async function init() {
  try {
    const me = await (await fetch('/api/me')).json();
    myName = me.user.name;
    myId = me.user.id;
  } catch (e) {
    myName = 'You';
  }

  let res;
  try {
    res = await request('join-room', { roomId });
  } catch (e) {
    finished = true;
    return showOverlay('Cannot join this meeting', e.message);
  }

  selfId = res.selfId;
  renderState(res.state);
  (res.chat || []).forEach((m) => addChat(m, true));
  updateButtons();

  try {
    device = new Device();
    await device.load({ routerRtpCapabilities: res.rtpCapabilities });
    await createTransports();
  } catch (e) {
    console.error(e);
    return showError('Could not set up video for this browser. Try the latest Chrome, Edge or Firefox.');
  }

  ready = true;
  [...res.producers, ...pendingProducers].forEach((p) => consumeProducer(p));
  pendingProducers.length = 0;

  await startInitialMedia();
}

socket.once('connect', init);