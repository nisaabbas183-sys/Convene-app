const path = require('path');
const fs = require('fs');
const http = require('http');
const crypto = require('crypto');
const express = require('express');
const { Server } = require('socket.io');
const mediasoup = require('mediasoup');
const mysql = require('mysql2/promise');

const PORT = process.env.PORT || 3000;
const MAX_PARTICIPANTS = 10;
const SESSION_MAX_AGE = 7 * 24 * 60 * 60; // seconds
const EMPTY_ROOM_TTL = 5 * 60 * 1000; // an empty meeting is removed after 5 minutes

// MySQL settings. XAMPP's default is user "root" with an empty password.
// If your MySQL has a password, set it before starting:  $env:DB_PASSWORD="your-password"
const DB_HOST = process.env.DB_HOST || 'localhost';
const DB_PORT = Number(process.env.DB_PORT || 3306);
const DB_USER = process.env.DB_USER || 'root';
const DB_PASSWORD = process.env.DB_PASSWORD || '';
const DB_NAME = process.env.DB_NAME || 'convene';
if (!/^[A-Za-z0-9_]+$/.test(DB_NAME)) {
  console.error('DB_NAME may only contain letters, numbers and underscores.');
  process.exit(1);
}

// mediasoup settings. ANNOUNCED_IP is the address browsers use to reach this server's media ports.
// 127.0.0.1 is right for testing on one computer. On a real server set it to the public IP.
const ANNOUNCED_IP = process.env.ANNOUNCED_IP || '127.0.0.1';
const RTC_MIN_PORT = Number(process.env.RTC_MIN_PORT || 40000);
const RTC_MAX_PORT = Number(process.env.RTC_MAX_PORT || 40100);

const MEDIA_CODECS = [
  { kind: 'audio', mimeType: 'audio/opus', clockRate: 48000, channels: 2 },
  { kind: 'video', mimeType: 'video/VP8', clockRate: 90000, parameters: { 'x-google-start-bitrate': 1000 } },
  {
    kind: 'video',
    mimeType: 'video/H264',
    clockRate: 90000,
    parameters: {
      'packetization-mode': 1,
      'profile-level-id': '42e01f',
      'level-asymmetry-allowed': 1,
      'x-google-start-bitrate': 1000,
    },
  },
];

const MAX_PRODUCERS_PER_PEER = 4; // mic + camera + screen (+1 spare)

// A small error must never take the whole server down.
process.on('uncaughtException', (err) => console.error('Uncaught exception:', err));
process.on('unhandledRejection', (err) => console.error('Unhandled rejection:', err));

const app = express();
const server = http.createServer(app);
const io = new Server(server, { pingInterval: 25000, pingTimeout: 60000 });

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

/* ---------- Database (MySQL) ---------- */
let db; // mysql2 connection pool

async function initDatabase() {
  // Create the database if it does not exist yet
  const admin = await mysql.createConnection({ host: DB_HOST, port: DB_PORT, user: DB_USER, password: DB_PASSWORD });
  await admin.query(
    `CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
  );
  await admin.end();

  db = mysql.createPool({
    host: DB_HOST,
    port: DB_PORT,
    user: DB_USER,
    password: DB_PASSWORD,
    database: DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
  });

  await db.query(`
    CREATE TABLE IF NOT EXISTS users (
      id CHAR(36) NOT NULL PRIMARY KEY,
      name VARCHAR(40) NOT NULL,
      email VARCHAR(255) NOT NULL UNIQUE,
      password_hash VARCHAR(255) NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);

  await importOldUsers();
}

// One-time import of accounts saved by the earlier version (data/users.json).
async function importOldUsers() {
  const file = path.join(__dirname, 'data', 'users.json');
  if (!fs.existsSync(file)) return;
  let old = [];
  try {
    old = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    return;
  }
  for (const u of old) {
    if (!u.id || !u.email || !u.password) continue;
    await db.query('INSERT IGNORE INTO users (id, name, email, password_hash) VALUES (?, ?, ?, ?)', [
      u.id,
      String(u.name || 'User').slice(0, 40),
      String(u.email).toLowerCase(),
      u.password,
    ]);
  }
  try {
    fs.renameSync(file, file + '.imported');
  } catch (e) {
    /* leave the file where it is */
  }
  console.log(`Imported ${old.length} account(s) from data/users.json into MySQL.`);
}

/* ---------- Passwords and sessions ---------- */
function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return `${salt.toString('hex')}:${hash.toString('hex')}`;
}

function verifyPassword(password, stored) {
  try {
    const [saltHex, hashHex] = stored.split(':');
    const expected = Buffer.from(hashHex, 'hex');
    const actual = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), 64);
    return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
  } catch (e) {
    return false;
  }
}

const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email });
const isEmail = (s) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);

// token -> { id, name, email } (kept in memory: users log in again after a server restart)
const sessions = new Map();

function parseCookies(header = '') {
  const out = {};
  header.split(';').forEach((part) => {
    const i = part.indexOf('=');
    if (i > -1) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  });
  return out;
}

function userFromCookie(header) {
  const token = parseCookies(header).sid;
  return (token && sessions.get(token)) || null;
}

function startSession(res, user) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, publicUser(user));
  res.setHeader('Set-Cookie', `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_MAX_AGE}`);
}

function safeNext(next) {
  return typeof next === 'string' && next.startsWith('/') && !next.startsWith('//') ? next : '/app';
}

/* ---------- Auth API ---------- */
app.post('/api/signup', async (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 40);
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');

  if (name.length < 2) return res.status(400).json({ error: 'Please enter your full name.' });
  if (!isEmail(email)) return res.status(400).json({ error: 'Please enter a valid email address.' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });

  try {
    const user = { id: crypto.randomUUID(), name, email };
    await db.query('INSERT INTO users (id, name, email, password_hash) VALUES (?, ?, ?, ?)', [
      user.id,
      name,
      email,
      hashPassword(password),
    ]);
    startSession(res, user);
    res.json({ user: publicUser(user) });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }
    console.error('signup failed:', err.message);
    res.status(500).json({ error: 'Could not create the account. Please try again.' });
  }
});

app.post('/api/login', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');

  try {
    const [rows] = await db.query('SELECT id, name, email, password_hash FROM users WHERE email = ? LIMIT 1', [email]);
    const row = rows[0];
    if (!row || !verifyPassword(password, row.password_hash)) {
      return res.status(401).json({ error: 'Incorrect email or password.' });
    }
    startSession(res, row);
    res.json({ user: publicUser(row) });
  } catch (err) {
    console.error('login failed:', err.message);
    res.status(500).json({ error: 'Could not log in. Please try again.' });
  }
});

app.post('/api/logout', (req, res) => {
  const token = parseCookies(req.headers.cookie).sid;
  if (token) sessions.delete(token);
  res.setHeader('Set-Cookie', 'sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
  res.json({ ok: true });
});

app.get('/api/me', (req, res) => {
  const user = userFromCookie(req.headers.cookie);
  if (!user) return res.status(401).json({ error: 'Not signed in.' });
  res.json({ user: publicUser(user) });
});

/* ---------- Pages ---------- */
const view = (file) => path.join(__dirname, 'views', file);

function requirePage(req, res, next) {
  if (userFromCookie(req.headers.cookie)) return next();
  res.redirect('/login?next=' + encodeURIComponent(req.originalUrl));
}

function guestOnlyPage(file) {
  return (req, res) => {
    if (userFromCookie(req.headers.cookie)) return res.redirect(safeNext(req.query.next));
    res.sendFile(view(file));
  };
}

app.get('/', (req, res) => res.sendFile(view('landing.html')));
app.get('/signup', guestOnlyPage('signup.html'));
app.get('/login', guestOnlyPage('login.html'));
app.get('/app', requirePage, (req, res) => res.sendFile(view('app.html')));
app.get('/room/:roomId', requirePage, (req, res) => res.sendFile(view('room.html')));

/* ---------- mediasoup worker ---------- */
let worker;

async function startWorker() {
  worker = await mediasoup.createWorker({
    rtcMinPort: RTC_MIN_PORT,
    rtcMaxPort: RTC_MAX_PORT,
    logLevel: 'warn',
  });
  worker.on('died', () => {
    console.error('mediasoup worker died, exiting in 2 seconds');
    setTimeout(() => process.exit(1), 2000);
  });
}

/* ---------- Rooms ---------- */
// rooms: roomId -> {
//   hostId, locked, createdAt, emptySince,
//   participants: Map(socketId -> { name, userId }),
//   router,                                  // mediasoup router (one per meeting)
//   audioLevelObserver,                      // detects who is speaking
//   peers: Map(socketId -> { transports, producers, consumers }),
//   banned: Set(userId),                     // people removed by the host
//   chat: [ { id, peerId, name, text, ts } ] // last 100 messages
// }
const rooms = new Map();

function newRoomId() {
  const s = crypto.randomBytes(5).toString('hex').slice(0, 9);
  return `${s.slice(0, 3)}-${s.slice(3, 7)}-${s.slice(7)}`;
}

// True when the person has a microphone stream that is not paused.
function micIsOn(room, socketId) {
  const peer = room.peers.get(socketId);
  if (!peer) return false;
  for (const p of peer.producers.values()) {
    if (p.appData.source === 'mic' && !p.paused) return true;
  }
  return false;
}

function roomState(roomId) {
  const room = rooms.get(roomId);
  if (!room) return null;
  return {
    roomId,
    hostId: room.hostId,
    locked: room.locked,
    participants: [...room.participants.entries()].map(([id, p]) => ({
      id,
      name: p.name,
      isHost: id === room.hostId,
      mic: micIsOn(room, id),
    })),
  };
}

// Sends the latest room state (people, host, lock, who is muted) to everyone in the meeting.
function broadcastState(roomId) {
  const state = roomState(roomId);
  if (state) io.to(roomId).emit('room-state', { state });
}

// Streams (mic, camera, screen) that other people in the meeting are sending.
function listProducers(room, exceptId) {
  const list = [];
  for (const [peerId, p] of room.peers) {
    if (peerId === exceptId) continue;
    for (const producer of p.producers.values()) {
      list.push({ producerId: producer.id, peerId, kind: producer.kind, source: producer.appData.source });
    }
  }
  return list;
}

function closeRoom(roomId) {
  const room = rooms.get(roomId);
  if (!room) return;
  try {
    room.router.close();
  } catch (e) {
    /* already closed */
  }
  rooms.delete(roomId);
}

// Remove meetings that nobody is in (never used, or everyone left a while ago).
setInterval(() => {
  const now = Date.now();
  for (const [id, room] of rooms) {
    if (room.participants.size === 0 && now - (room.emptySince || room.createdAt) > EMPTY_ROOM_TTL) closeRoom(id);
  }
}, 30 * 1000).unref();

// Takes one person out of a meeting (they left, lost connection, or the host removed them).
function removeFromRoom(roomId, socketId) {
  const sock = io.sockets.sockets.get(socketId);
  if (sock) {
    sock.data.roomId = null;
    sock.leave(roomId);
  }
  const room = rooms.get(roomId);
  if (!room || !room.participants.has(socketId)) return;

  // Closing a transport also closes its producers and consumers; other people's
  // consumers of this person's streams get a 'producerclose' event automatically.
  const peer = room.peers.get(socketId);
  if (peer) {
    for (const transport of [...peer.transports.values()]) {
      try {
        transport.close();
      } catch (e) {
        /* already closed */
      }
    }
    room.peers.delete(socketId);
  }
  const leaver = room.participants.get(socketId);
  room.participants.delete(socketId);

  if (room.participants.size === 0) {
    // Keep the meeting for a few minutes so a page refresh does not lose it.
    room.hostId = null;
    room.locked = false;
    room.emptySince = Date.now();
    return;
  }
  // If the host leaves, the longest-present participant becomes host
  if (room.hostId === socketId) room.hostId = room.participants.keys().next().value;
  io.to(roomId).emit('participant-left', { id: socketId, name: leaver ? leaver.name : 'Someone', state: roomState(roomId) });
}

function requireApiAuth(req, res, next) {
  if (userFromCookie(req.headers.cookie)) return next();
  res.status(401).json({ error: 'Not signed in.' });
}

app.post('/api/rooms', requireApiAuth, async (req, res) => {
  try {
    let id = newRoomId();
    while (rooms.has(id)) id = newRoomId();
    const router = await worker.createRouter({ mediaCodecs: MEDIA_CODECS });

    const audioLevelObserver = await router.createAudioLevelObserver({ maxEntries: 1, threshold: -60, interval: 800 });
    audioLevelObserver.on('volumes', (volumes) => {
      io.to(id).emit('active-speaker', { peerId: volumes[0].producer.appData.peerId });
    });
    audioLevelObserver.on('silence', () => io.to(id).emit('active-speaker', { peerId: null }));

    rooms.set(id, {
      hostId: null,
      locked: false,
      createdAt: Date.now(),
      emptySince: null,
      participants: new Map(),
      router,
      audioLevelObserver,
      peers: new Map(),
      banned: new Set(),
      chat: [],
    });
    res.json({ roomId: id });
  } catch (err) {
    console.error('create room failed:', err.message);
    res.status(500).json({ error: 'Could not create the meeting.' });
  }
});

app.get('/api/rooms/:roomId', requireApiAuth, (req, res) => {
  const room = rooms.get(req.params.roomId);
  if (!room) return res.status(404).json({ error: 'Meeting not found. Check the code and try again.' });
  res.json({ exists: true, count: room.participants.size, max: MAX_PARTICIPANTS, locked: room.locked });
});

/* ---------- Realtime (Socket.io) ---------- */
io.use((socket, next) => {
  const user = userFromCookie(socket.request.headers.cookie);
  if (!user) return next(new Error('unauthorized'));
  socket.data.user = user;
  next();
});

io.on('connection', (socket) => {
  const user = socket.data.user;
  socket.data.roomId = null;
  let recentChats = []; // timestamps, used to slow down message flooding

  const ctx = () => {
    const roomId = socket.data.roomId;
    const room = roomId && rooms.get(roomId);
    const peer = room && room.peers.get(socket.id);
    return room && peer ? { roomId, room, peer } : null;
  };

  // Registers an event that needs the person to be in a meeting.
  // Handlers get (data, { roomId, room, peer }) and return the reply object.
  function handle(event, fn) {
    socket.on(event, async (data, cb) => {
      if (typeof data === 'function') {
        cb = data;
        data = {};
      }
      if (typeof cb !== 'function') cb = () => {};
      const c = ctx();
      if (!c) return cb({ error: 'Join a meeting first.' });
      try {
        cb(await fn(data || {}, c));
      } catch (err) {
        console.error(`[${event}]`, err.message);
        cb({ error: 'Something went wrong. Please try again.' });
      }
    });
  }

  socket.on('join-room', ({ roomId } = {}, cb = () => {}) => {
    const room = rooms.get(roomId);
    if (!room) return cb({ error: 'Meeting not found.' });
    if (socket.data.roomId) return cb({ error: 'You are already in a meeting.' });
    if (room.banned.has(user.id)) return cb({ error: 'You were removed from this meeting by the host.' });
    if (room.locked && room.hostId) return cb({ error: 'This meeting is locked by the host.' });
    if (room.participants.size >= MAX_PARTICIPANTS)
      return cb({ error: `This meeting is full (maximum ${MAX_PARTICIPANTS} participants).` });

    room.participants.set(socket.id, { name: user.name, userId: user.id });
    room.peers.set(socket.id, { transports: new Map(), producers: new Map(), consumers: new Map() });
    room.emptySince = null;
    if (!room.hostId) room.hostId = socket.id; // first person in becomes host
    socket.data.roomId = roomId;
    socket.join(roomId);

    cb({
      ok: true,
      selfId: socket.id,
      state: roomState(roomId),
      chat: room.chat,
      rtpCapabilities: room.router.rtpCapabilities,
      producers: listProducers(room, socket.id),
    });
    socket.to(roomId).emit('participant-joined', { id: socket.id, name: user.name, state: roomState(roomId) });
  });

  /* --- media signalling --- */
  handle('get-rtp-capabilities', async (data, { room }) => ({
    rtpCapabilities: room.router.rtpCapabilities,
  }));

  handle('create-transport', async (data, { room, peer }) => {
    const direction = data.direction === 'send' ? 'send' : 'recv';
    if (peer.transports.size >= 4) return { error: 'Too many connections.' };
    const transport = await room.router.createWebRtcTransport({
      listenInfos: [
        { protocol: 'udp', ip: '0.0.0.0', announcedAddress: ANNOUNCED_IP },
        { protocol: 'tcp', ip: '0.0.0.0', announcedAddress: ANNOUNCED_IP },
      ],
      initialAvailableOutgoingBitrate: 800000,
      appData: { direction },
    });
    peer.transports.set(transport.id, transport);
    transport.observer.on('close', () => peer.transports.delete(transport.id));
    return {
      id: transport.id,
      iceParameters: transport.iceParameters,
      iceCandidates: transport.iceCandidates,
      dtlsParameters: transport.dtlsParameters,
    };
  });

  handle('connect-transport', async ({ transportId, dtlsParameters }, { peer }) => {
    const transport = peer.transports.get(transportId);
    if (!transport) return { error: 'Unknown transport.' };
    await transport.connect({ dtlsParameters });
    return { ok: true };
  });

  handle('produce', async ({ transportId, kind, rtpParameters, appData }, { roomId, room, peer }) => {
    const transport = peer.transports.get(transportId);
    if (!transport) return { error: 'Unknown transport.' };
    if (kind !== 'audio' && kind !== 'video') return { error: 'Invalid media kind.' };
    if (peer.producers.size >= MAX_PRODUCERS_PER_PEER) return { error: 'Too many media streams.' };

    // The client may call the camera "cam"; the server calls it "camera".
    const asked = appData && appData.source === 'cam' ? 'camera' : appData && appData.source;
    const source = ['mic', 'camera', 'screen'].includes(asked) ? asked : kind === 'audio' ? 'mic' : 'camera';
    if ((source === 'mic') !== (kind === 'audio')) return { error: 'Media kind does not match.' };

    for (const p of peer.producers.values()) {
      if (p.appData.source === source) return { error: 'This stream is already being sent.' };
    }
    // Only one person can present at a time.
    if (source === 'screen') {
      for (const other of room.peers.values()) {
        for (const p of other.producers.values()) {
          if (p.appData.source === 'screen') return { error: 'Someone else is already sharing their screen.' };
        }
      }
    }

    const producer = await transport.produce({ kind, rtpParameters, appData: { source, peerId: socket.id } });
    peer.producers.set(producer.id, producer);
    producer.observer.on('close', () => peer.producers.delete(producer.id));
    if (source === 'mic') {
      room.audioLevelObserver.addProducer({ producerId: producer.id }).catch(() => {});
      broadcastState(roomId);
    }

    socket.to(roomId).emit('new-producer', {
      producerId: producer.id,
      peerId: socket.id,
      kind,
      source,
    });
    return { id: producer.id };
  });

  handle('get-producers', async (data, { room }) => ({ producers: listProducers(room, socket.id) }));

  handle('consume', async ({ producerId, transportId, rtpCapabilities }, { room, peer }) => {
    const transport = transportId
      ? peer.transports.get(transportId)
      : [...peer.transports.values()].find((t) => t.appData.direction === 'recv');
    if (!transport) return { error: 'Unknown transport.' };

    let ownerId = null;
    let producer = null;
    for (const [peerId, p] of room.peers) {
      if (p.producers.has(producerId)) {
        ownerId = peerId;
        producer = p.producers.get(producerId);
      }
    }
    if (!producer || ownerId === socket.id) return { error: 'Stream not found.' };
    if (!room.router.canConsume({ producerId, rtpCapabilities })) return { error: 'Cannot play this stream.' };

    // Start paused; the client resumes once it is ready to play.
    const consumer = await transport.consume({ producerId, rtpCapabilities, paused: true });
    peer.consumers.set(consumer.id, consumer);
    consumer.observer.on('close', () => peer.consumers.delete(consumer.id));
    consumer.on('producerclose', () => {
      socket.emit('consumer-closed', { consumerId: consumer.id, producerId });
    });
    consumer.on('producerpause', () =>
      socket.emit('consumer-state', { consumerId: consumer.id, producerId, paused: true })
    );
    consumer.on('producerresume', () =>
      socket.emit('consumer-state', { consumerId: consumer.id, producerId, paused: false })
    );

    return {
      id: consumer.id,
      producerId,
      peerId: ownerId,
      kind: consumer.kind,
      source: producer.appData.source,
      rtpParameters: consumer.rtpParameters,
      producerPaused: consumer.producerPaused,
    };
  });

  handle('resume-consumer', async ({ consumerId }, { peer }) => {
    const consumer = peer.consumers.get(consumerId);
    if (!consumer) return { error: 'Unknown consumer.' };
    await consumer.resume();
    return { ok: true };
  });

  handle('pause-producer', async ({ producerId }, { roomId, peer }) => {
    const producer = peer.producers.get(producerId);
    if (!producer) return { error: 'Unknown producer.' };
    await producer.pause();
    broadcastState(roomId);
    return { ok: true };
  });

  handle('resume-producer', async ({ producerId }, { roomId, peer }) => {
    const producer = peer.producers.get(producerId);
    if (!producer) return { error: 'Unknown producer.' };
    await producer.resume();
    broadcastState(roomId);
    return { ok: true };
  });

  handle('close-producer', async ({ producerId }, { roomId, peer }) => {
    const producer = peer.producers.get(producerId);
    if (!producer) return { error: 'Unknown producer.' };
    producer.close();
    socket.to(roomId).emit('producer-closed', { producerId, peerId: socket.id });
    broadcastState(roomId);
    return { ok: true };
  });

  /* --- chat --- */
  handle('chat-message', async ({ text }, { roomId, room }) => {
    const clean = String(text || '').trim().slice(0, 500);
    if (!clean) return { error: 'Type a message first.' };

    const now = Date.now();
    recentChats = recentChats.filter((t) => now - t < 5000);
    if (recentChats.length >= 8) return { error: 'You are sending messages too quickly.' };
    recentChats.push(now);

    const msg = { id: crypto.randomUUID(), peerId: socket.id, userId: user.id, name: user.name, text: clean, ts: now, time: now };
    room.chat.push(msg);
    if (room.chat.length > 100) room.chat.shift();
    io.to(roomId).emit('chat-message', msg);
    return { ok: true };
  });

  /* --- host controls (every action checks that the caller is the host) --- */
  const NOT_HOST = { error: 'Only the host can do that.' };

  // Mutes one person's microphone. Returns true if the person is in the meeting.
  async function muteMic(targetId) {
    const room = rooms.get(socket.data.roomId);
    const target = room && room.peers.get(targetId);
    if (!target) return false;
    for (const p of target.producers.values()) {
      if (p.appData.source === 'mic' && !p.paused) await p.pause();
    }
    io.to(targetId).emit('force-muted');
    return true;
  }

  handle('host-mute', async (data, { roomId, room }) => {
    if (room.hostId !== socket.id) return NOT_HOST;
    const targetId = data.targetId || data.peerId;
    if (!targetId || targetId === socket.id || !(await muteMic(targetId))) return { error: 'Participant not found.' };
    broadcastState(roomId);
    return { ok: true };
  });

  handle('host-mute-all', async (data, { roomId, room }) => {
    if (room.hostId !== socket.id) return NOT_HOST;
    for (const id of room.participants.keys()) {
      if (id !== socket.id) await muteMic(id);
    }
    broadcastState(roomId);
    return { ok: true };
  });

  handle('host-remove', async (data, { roomId, room }) => {
    if (room.hostId !== socket.id) return NOT_HOST;
    const targetId = data.targetId || data.peerId;
    if (targetId === socket.id) return { error: 'You cannot remove yourself. Use Leave or End for all.' };
    const target = room.participants.get(targetId);
    if (!target) return { error: 'Participant not found.' };
    room.banned.add(target.userId); // they cannot rejoin this meeting
    io.to(targetId).emit('removed');
    removeFromRoom(roomId, targetId);
    return { ok: true };
  });

  handle('host-lock', async ({ locked }, { roomId, room }) => {
    if (room.hostId !== socket.id) return NOT_HOST;
    room.locked = !!locked;
    broadcastState(roomId);
    return { ok: true, locked: room.locked };
  });

  handle('host-end', async (data, { roomId, room }) => {
    if (room.hostId !== socket.id) return NOT_HOST;
    io.to(roomId).emit('meeting-ended');
    for (const id of [...room.participants.keys()]) {
      const s = io.sockets.sockets.get(id);
      if (s) {
        s.data.roomId = null;
        s.leave(roomId);
      }
    }
    closeRoom(roomId);
    return { ok: true };
  });

  const leave = () => {
    if (socket.data.roomId) removeFromRoom(socket.data.roomId, socket.id);
  };
  socket.on('leave-room', leave);
  socket.on('disconnect', (reason) => {
    console.log(`[socket] ${user.name} disconnected: ${reason}`);
    leave();
  });
});

/* ---------- Start ---------- */
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use. Close the other server window and try again.`);
  } else {
    console.error('Server error:', err);
  }
  process.exit(1);
});

async function start() {
  try {
    await initDatabase();
    console.log(`MySQL ready (database "${DB_NAME}" on ${DB_HOST}:${DB_PORT})`);
  } catch (err) {
    console.error('Could not connect to MySQL:', err.message);
    console.error('Check that MySQL is running, and that DB_USER and DB_PASSWORD are correct.');
    process.exit(1);
  }

  try {
    await startWorker();
  } catch (err) {
    console.error('Could not start the mediasoup media server:', err.message);
    process.exit(1);
  }

  server.listen(PORT, () => {
    console.log(`Convene is running at http://localhost:${PORT}`);
    console.log(`Media server ready (announced IP ${ANNOUNCED_IP}, UDP/TCP ports ${RTC_MIN_PORT}-${RTC_MAX_PORT})`);
  });
}

start();