// Shared script for the sign up and log in pages.
const form = document.getElementById('form');
const errorEl = document.getElementById('error');
const submitBtn = document.getElementById('submit');
const isSignup = location.pathname === '/signup';

// Keep the "next" destination (e.g. a meeting link) when switching between pages.
const params = new URLSearchParams(location.search);
const rawNext = params.get('next');
const next = rawNext && rawNext.startsWith('/') && !rawNext.startsWith('//') ? rawNext : '/app';
if (rawNext) {
  const alt = document.getElementById('altLink');
  alt.href = alt.getAttribute('href') + '?next=' + encodeURIComponent(next);
}

function showError(message) {
  errorEl.textContent = message;
  errorEl.hidden = false;
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errorEl.hidden = true;

  const body = Object.fromEntries(new FormData(form).entries());
  submitBtn.disabled = true;
  const label = submitBtn.textContent;
  submitBtn.textContent = isSignup ? 'Creating account…' : 'Logging in…';

  try {
    const res = await fetch(isSignup ? '/api/signup' : '/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      showError(data.error || 'Something went wrong. Please try again.');
    } else {
      location.href = next;
      return;
    }
  } catch (err) {
    showError('Could not reach the server. Check your connection and try again.');
  }
  submitBtn.disabled = false;
  submitBtn.textContent = label;
});