// Dashboard logic
const createError = document.getElementById('createError');
const joinError = document.getElementById('joinError');

function show(el, message) {
  el.textContent = message;
  el.hidden = false;
}

async function loadUser() {
  const res = await fetch('/api/me');
  if (!res.ok) {
    location.href = '/login';
    return;
  }
  const { user } = await res.json();
  const first = user.name.split(' ')[0];
  document.getElementById('greeting').textContent = `Welcome, ${first}`;
  document.getElementById('who').textContent = user.name;
  document.getElementById('avatar').textContent = user.name.trim()[0].toUpperCase();
}

document.getElementById('create').onclick = async () => {
  createError.hidden = true;
  const res = await fetch('/api/rooms', { method: 'POST' });
  if (!res.ok) return show(createError, 'Could not create the meeting. Please try again.');
  const { roomId } = await res.json();
  location.href = '/room/' + roomId;
};

document.getElementById('joinForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  joinError.hidden = true;
  let code = document.getElementById('code').value.trim();
  const m = code.match(/room\/([a-z0-9-]+)/i); // accept a pasted link too
  if (m) code = m[1];
  if (!code) return show(joinError, 'Enter a meeting code.');

  const res = await fetch('/api/rooms/' + encodeURIComponent(code));
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return show(joinError, data.error || 'Meeting not found.');
  if (data.locked) return show(joinError, 'This meeting is locked by the host.');
  if (data.count >= data.max) return show(joinError, 'This meeting is full.');
  location.href = '/room/' + code;
});

document.getElementById('logout').onclick = async () => {
  await fetch('/api/logout', { method: 'POST' });
  location.href = '/';
};

loadUser();