const roomId = location.pathname.split('/').pop();

const gridEl = document.getElementById('grid');
const peopleEl = document.getElementById('people');
const countEl = document.getElementById('count');
const errorEl = document.getElementById('error');
const toastEl = document.getElementById('toast');

document.getElementById('roomCode').textContent = roomId;

let selfId = null;
let myName = '';
let localStream = null;

const socket = io();

function initials(name) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('') || '?';
}

function toast(message) {
  toastEl.textContent = message;
  toastEl.classList.add('show');
  setTimeout(() => toastEl.classList.remove('show'), 2000);
}

function showError(message) {
  errorEl.textContent = message;
  errorEl.hidden = false;
}

function renderState(state) {
  if (!state) return;
  const n = state.participants.length;
  countEl.textContent = `${n} participant${n === 1 ? '' : 's'}`;

  peopleEl.innerHTML = '';
  gridEl.querySelectorAll('.tile[data-remote]').forEach((t) => t.remove());

  state.participants.forEach((p) => {
    const li = document.createElement('li');
    const avatar = document.createElement('div');
    avatar.className = 'avatar';
    avatar.textContent = initials(p.name);
    const label = document.createElement('span');
    label.textContent = p.name + (p.id === selfId ? ' (You)' : '');
    li.append(avatar, label);
    if (p.isHost) {
      const b = document.createElement('span');
      b.className = 'badge';
      b.textContent = 'Host';
      li.appendChild(b);
    }
    peopleEl.appendChild(li);

    // Remote video arrives in the next phase; for now show a name tile.
    if (p.id !== selfId) {
      const tile = document.createElement('div');
      tile.className = 'tile';
      tile.dataset.remote = p.id;
      const circle = document.createElement('div');
      circle.className = 'initials';
      circle.textContent = initials(p.name);
      const tag = document.createElement('div');
      tag.className = 'label';
      tag.textContent = p.name;
      tile.append(circle, tag);
      gridEl.appendChild(tile);
    }
  });
}

async function startLocalPreview() {
  const tile = document.createElement('div');
  tile.className = 'tile';
  tile.id = 'selfTile';
  const circle = document.createElement('div');
  circle.className = 'initials';
  circle.textContent = initials(myName);
  const tag = document.createElement('div');
  tag.className = 'label';
  tag.textContent = myName + ' (You)';
  tile.append(circle, tag);
  gridEl.prepend(tile);

  try {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
  } catch (e) {
    showError('Camera or microphone access was blocked. Allow access in your browser and reload the page. (HTTPS or localhost is required.)');
    return;
  }
  const video = document.createElement('video');
  video.autoplay = true;
  video.muted = true; // avoid hearing yourself
  video.playsInline = true;
  video.srcObject = localStream;
  tile.prepend(video);
}

function toggleTrack(kind, button, onText, offText) {
  if (!localStream) return toast('Camera or microphone is not available.');
  const tracks = kind === 'audio' ? localStream.getAudioTracks() : localStream.getVideoTracks();
  if (!tracks.length) return;
  const enable = !tracks[0].enabled;
  tracks.forEach((t) => (t.enabled = enable));
  button.classList.toggle('off', !enable);
  button.setAttribute('aria-pressed', String(!enable));
  button.querySelector('span').textContent = enable ? onText : offText;
  const tile = document.getElementById('selfTile');
  if (kind === 'video' && tile && tile.querySelector('video')) {
    tile.querySelector('video').style.visibility = enable ? 'visible' : 'hidden';
  }
}

document.getElementById('mic').onclick = (e) => toggleTrack('audio', e.currentTarget, 'Mute', 'Unmute');
document.getElementById('cam').onclick = (e) => toggleTrack('video', e.currentTarget, 'Stop video', 'Start video');

document.getElementById('copy').onclick = async () => {
  try {
    await navigator.clipboard.writeText(location.href);
    toast('Meeting link copied');
  } catch (e) {
    toast('Copy failed. Copy the link from the address bar.');
  }
};

function leaveMeeting() {
  socket.emit('leave-room');
  if (localStream) localStream.getTracks().forEach((t) => t.stop());
  location.href = '/app';
}
document.getElementById('leave').onclick = leaveMeeting;

socket.on('connect_error', (err) => {
  if (err.message === 'unauthorized') {
    location.href = '/login?next=' + encodeURIComponent(location.pathname);
  } else {
    showError('Connection problem. Please check your internet and reload.');
  }
});

socket.on('connect', async () => {
  try {
    const me = await (await fetch('/api/me')).json();
    myName = me.user.name;
  } catch (e) {
    myName = 'You';
  }
  socket.emit('join-room', { roomId }, (res) => {
    if (res.error) return showError(res.error);
    selfId = res.selfId;
    renderState(res.state);
    if (!document.getElementById('selfTile')) startLocalPreview();
  });
});

socket.on('participant-joined', ({ name, state }) => {
  renderState(state);
  toast(`${name} joined`);
});
socket.on('participant-left', ({ state }) => renderState(state));